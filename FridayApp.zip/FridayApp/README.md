# Friday — Android voice assistant app

A real native Android app. It runs in the background as a foreground service,
listens for **"Hey Friday"**, and answers out loud.

## What it can do

| Say | Friday does |
|---|---|
| "Hey Friday, what time is it" | Speaks the time |
| "Hey Friday, what is the date" | Speaks the date |
| "Hey Friday, open whatsapp" | Opens any installed app by name |
| "Hey Friday, play lofi" | Opens YouTube Music and plays it |
| "Hey Friday, search cats" | Searches the web |
| "Hey Friday, who is APJ Abdul Kalam" | Answers from the internet, out loud |
| "Hey Friday, where is Dal Lake" | Finds the place and opens it on Maps |
| "Hey Friday, weather in Srinagar" | Speaks the weather |
| "Hey Friday, tell me a joke" | Tells a joke |

No API keys needed — questions use DuckDuckGo/Wikipedia, places use
OpenStreetMap, weather uses wttr.in.

## How to build the APK (needs a computer, once)

1. Install **Android Studio** (free) from developer.android.com/studio
2. Open this `FridayApp` folder in Android Studio and let it sync
3. Connect your phone with USB debugging on (or use an emulator)
4. Press **Run** — the app installs on your phone
5. Open Friday, tap **Start Friday**, allow the mic, and tap the battery
   button so Android doesn't kill it in the background

To get a shareable APK file instead: in Android Studio go to
**Build → Build App Bundle(s) / APK(s) → Build APK(s)**.

## Honest limits

- Friday listens while the phone is awake and the service runs. A normal app
  cannot listen while the phone is fully asleep the way Siri or Google
  Assistant can — that power is reserved for the system assistant.
- Voice recognition uses Google's speech service, so it needs internet.
- Keeping the mic on uses extra battery. Tap **Stop Friday** when you don't
  need it.
