package com.friday.assistant

import android.Manifest
import android.animation.ObjectAnimator
import android.view.animation.LinearInterpolator
import android.widget.ImageView
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var logView: TextView
    private lateinit var scroller: ScrollView

    private val logReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val line = intent?.getStringExtra(FridayService.EXTRA_LINE) ?: return
            appendLog(line)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        logView = findViewById(R.id.logView)
        scroller = findViewById(R.id.scroller)

        // The FRIDAY core spins continuously, like a live hologram.
        val orb = findViewById<ImageView>(R.id.orbView)
        ObjectAnimator.ofFloat(orb, "rotation", 0f, 360f).apply {
            duration = 12000
            interpolator = LinearInterpolator()
            repeatCount = ObjectAnimator.INFINITE
            start()
        }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            if (hasPermissions()) {
                startFriday()
            } else {
                requestPermissions()
            }
        }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            stopService(Intent(this, FridayService::class.java))
            appendLog("Friday stopped.")
        }
        findViewById<Button>(R.id.btnBattery).setOnClickListener {
            // Ask Android not to kill Friday in the background.
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } catch (e: Exception) {
                appendLog("Open Settings > Battery yourself and exempt Friday.")
            }
        }

        appendLog("Tap START FRIDAY, then say \"Hey Friday\" any time.")
        appendLog("Try: \"Hey Friday, what time is it\", \"Hey Friday, open whatsapp\",")
        appendLog("\"Hey Friday, play lofi\", \"Hey Friday, where is Dal Lake\",")
        appendLog("\"Hey Friday, roast me\" — if you dare.")
    }

    override fun onResume() {
        super.onResume()
        // Android 14 requires an exported flag for runtime receivers.
        // This one is internal only, so it must NOT be exported.
        val filter = IntentFilter(FridayService.ACTION_LOG)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(logReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(logReceiver, filter)
        }
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(logReceiver) } catch (e: Exception) {}
    }

    private fun hasPermissions(): Boolean {
        val mic = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        val notif = if (Build.VERSION.SDK_INT >= 33) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        } else true
        return mic && notif
    }

    private fun requestPermissions() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        ActivityCompat.requestPermissions(this, perms.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (hasPermissions()) startFriday()
        else appendLog("Friday needs mic permission to hear you.")
    }

    private fun startFriday() {
        val intent = Intent(this, FridayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        appendLog("Friday started in the background.")
    }

    private fun appendLog(line: String) {
        logView.append("\n$line")
        scroller.post { scroller.fullScroll(ScrollView.FOCUS_DOWN) }
    }
}
